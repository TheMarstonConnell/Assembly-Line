# Assembly Line - Assembly Code Emulator

An assembly emulator based on one used in school. Handles both machine code and assembly with a toggle in the menu. 

Written in Java because my Computer Engineering courses emulator was god awful to use. So this fixes all the stupid formatting rules and cleans everything up almost acting as a full IDE.
